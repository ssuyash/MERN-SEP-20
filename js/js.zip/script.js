var a = 21


//Number
var a = 10    //Number integer
var b = 10.2 // Number Decimal/ float
var c = Infinity
var d = 0b101011 //binary number
var e = 0O71264 //octal number
var f = 0xfab850 //hexadecimal number
var g = NaN // Not a Number




console.log(d)


//Wap to swap two numbers .


var a = 10  //paani
var b = 20 // milk

console.log("Before Swapping")
console.log("value of a is : ", a)
console.log("value of b is : ", b)


//logic 
var c = a
a = b
b = c 


console.log("after Swapping")
console.log("value of a is : ", a)
console.log("value of b is : ", b)



//Boolean Type
var isMarriedc = false
var isDataRecvd = true


//String  (group of characters)

var name = "Bhavishya"
var lastName = 'Jain'
var jd = `wp developer`

// your's

var str = "your's"

//string interpolation
var str = `Good Morning ${name}`
console.log(str)




//Array  (array is a group of data)

var students = ["Bhavishya", "Alpna", "Piyush", "Nandanee", 5, false, {} , [] ]
console.log(students[3])


//Object (key-value pair)
var stundenDetails = {
    name:'Bhavishya',
    lastName:"Patel",
    qualification:"Graduate"
}


console.log(stundenDetails.qualification)
console.log(stundenDetails['name']) 


//null 
stundenDetails = null

//undefined
var  x
console.log(x)