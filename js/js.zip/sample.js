
var sum = 1
var n = 5
for(var i=1; i<=n; i++){
    sum = sum*i
}

console.log(sum)
