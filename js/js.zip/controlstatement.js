// If statement

// if(){
//     //code if condition is true
// }


// var age = 17

// if(age>=18){
//     console.log("you can vote")
// }


// if(condition){
//     //this code will run if condition is true
// }else{
//     //this code will run if condition will false
// }



// var age = 19
// if(age>=18){
//     console.log("you can vote")
// }else{
//     console.log("you can not vote")
// }


// var num1 = 200
// var num2 = 250
// var num3 = 10000

// if(num1 >  num2){
//     //numb1 is bigger than num2
//     if(num1 > num3){
//         console.log(num1)
//     }else{
//         console.log(num3)
//     }
// }else{
//     //numb2 is bigger than num1
//     if(num2 > num3){
//         console.log(num2)
//     }else{
//         console.log(num3)
//     }

// }



var num = 110

// if(num > 0){
//     console.log("Number is positive")
// }else if(num < 0){
//     console.log("Number is negative")
// }else{
//     console.log("Number is Zero")
// }



// if(num%5 == 0 && num%11 == 0){
//     console.log("yes")
// }else{
//     console.log("no")
// }


// switch-case
var day = 3

switch(day){
    case 1 :
        console.log("Monday")
        break

    case 2 :
        console.log("Tuesday")
        break
    case 3 :
        console.log("Wednesday")
        break

    case 4 :
        console.log("Thursday")
        break

    case 5:
        console.log("Friday")
        break

    case 6:
        console.log("Saturday")
        break

    case 7:
        console.log("Sunday")
        break
    
    default:
        console.log("Invalid day")


}
