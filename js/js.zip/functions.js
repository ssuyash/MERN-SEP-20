//Syntex :
var a = 50

function greet(name){
    console.log("Good Morning",name)    
}


function addTwoNumber(a, b){
    console.log(a)
    var ans = a+b
    return ans
}

var returnRes = greet("Alpna")
var result = addTwoNumber(5, 3)
console.log(result, returnRes)










function pow(a, b){   
    var power = 1    
    for(var i=1; i<=b; i++){
        power *= a
    }       
    return power
}


var ans = pow(3,5)
console.log(ans)