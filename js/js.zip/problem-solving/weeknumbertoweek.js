var day = 50

if(day == 1){
    console.log("monday")
}else if(day == 2){
    console.log("tuesday")
}else if(day == 3){
    console.log("wed")
}else if(day == 4){
    console.log("thus")
}else if(day == 5){
    console.log("fri")
}else if(day == 6){
    console.log('sat')
}else if(day == 7){
    console.log('sun')
}else{
    console.log("invalid day")
}