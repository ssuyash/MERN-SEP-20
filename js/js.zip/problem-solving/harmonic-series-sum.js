var terms = 5

var sum = 0
for(var i=1; i<=terms; i++){
    sum += 1/i;
    console.log(1+"/"+i)
}

console.log("Sum of series : ", sum)