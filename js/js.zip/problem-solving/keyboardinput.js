var sum = 0
var numOfInput = 3
for(var i=1; i<=numOfInput; i++){
    var num = parseInt(prompt('enter a number'))
    sum += num
}


console.log(sum)
console.log(sum/numOfInput)