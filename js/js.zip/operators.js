// data => operand
// operator



//1) Assignmnet Operator (=)

//  var a = 24
//  var b = 5 
  //  a += 5  // a = a+5

    // -=
    // *=  
    // /= 
    // %=






 
//2) Arithmatic Operators 

//i) Addition Operator (+) / Concatation Operator (+)
//ii) Subtraction Operator (-)
//iii) Division Operator (*)
//iv) Multiplication (/)
// v) Modulus Operator (%)


//console.log(a % b)

//x % n   (0, n-1)

// 5 % 5  => 0
// 6 % 5  => 1
// 7 % 5  => 2
// 8 % 5  => 3
// 9 % 5  => 4
// 10 % 5  => 0
// 11 % 5  => 1


//3)  Increment ( by 1) Decrement(by 1) Operators
// var d = 20
// var c = 20

//Post increament
//var sum = c++ + d++


//Pre increment
//var sum = ++c + ++d


//console.log(sum, c, d)
// console.log(++c)


//4) Comparison Operator (boolean)

// Greater than ( > )
// Less than ( < )
// Equal to  ( == )
// Not Equal to ( != )
// Strict Equal ( === )
// Not Strict Equal ( !== )
//Greater or equal
//Less or Equal


// var a = 20
// var b = '20'
// console.log(a===b)





// 5) conditional operator (ternery operator)

//condition ? it will run if condition is true : it will run if condition is false

// it will run if condition is false



//6) Logical Operator
//(true => 1 false => 0)

// AND (&&)
// OR (||)
// NOT (!)

// var num = 10
// var isDivisible = num%5 == 0 || num%11 == 0
// console.log(isDivisible)


